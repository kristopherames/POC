﻿using System.Collections.Generic;
using VendingMachine.Areas.Simulator.Models;

namespace VendingMachine.Repository
{
    public class PhysicalContentsRepository : IPhysicalContentsRepository
    {
        #region Implementation of IPhysicalContentsRepository

        /// <summary>
        /// Initializes the inventory list.
        /// </summary>
        /// <returns></returns>
        public List<InventoryItemModel> InitializeInventoryList()
        {
            var inventoryList = new List<InventoryItemModel>();

            inventoryList.Add(CreateInventoryItem("01", "Cinnamon bun", 2m));
            inventoryList.Add(CreateInventoryItem("02", "Cookies", 1.75m));
            inventoryList.Add(CreateInventoryItem("03", "Donuts", 1.5m));
            inventoryList.Add(CreateInventoryItem("04", "Candy", 1.25m));
            inventoryList.Add(CreateInventoryItem("05", "Potato chips", 1.25m));
            inventoryList.Add(CreateInventoryItem("06", "Cheezy poofs", 1m));
            inventoryList.Add(CreateInventoryItem("07", "Pretzels", 1m));
            inventoryList.Add(CreateInventoryItem("08", "Crackers", .75m));
            inventoryList.Add(CreateInventoryItem("09", "Mint gum", .5m));
            inventoryList.Add(CreateInventoryItem("10", "Fruity gum", .5m));

            return inventoryList;
        }

        /// <summary>
        /// Creates the default cash onhand.
        /// </summary>
        /// <returns></returns>
        public CurrencyModel CreateDefaultCashOnhand()
        {
            var cashOnhand = new CurrencyModel();

            cashOnhand.DimeQuantity = 5;
            cashOnhand.FiveDollarBillQuantity = 5;
            cashOnhand.NickelQuantity = 5;
            cashOnhand.OneDollarBillQuantity = 5;
            cashOnhand.QuarterQuantity = 5;

            return cashOnhand;
        }

        #endregion


        #region Private Helper Methods

        private InventoryItemModel CreateInventoryItem(string itemNumber, string description, decimal price)
        {
            var inventoryItem = new InventoryItemModel(itemNumber, description, price);
            inventoryItem.Quantity = 5;

            return inventoryItem;
        }

        #endregion
    }
}