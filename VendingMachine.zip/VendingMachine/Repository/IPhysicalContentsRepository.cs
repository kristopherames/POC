﻿using System.Collections.Generic;
using VendingMachine.Areas.Simulator.Models;

namespace VendingMachine.Repository
{
    public interface IPhysicalContentsRepository
    {
        /// <summary>
        /// Initializes the inventory list.
        /// </summary>
        /// <returns></returns>
        List<InventoryItemModel> InitializeInventoryList();

        /// <summary>
        /// Creates the default cash onhand.
        /// </summary>
        /// <returns></returns>
        CurrencyModel CreateDefaultCashOnhand();
    }
}