﻿using VendingMachine.MockServices;

namespace VendingMachine.Repository
{
    public class CreditCardRepository : ICreditCardRepository
    {
        #region Properties

        private readonly IMockCreditCardService _mockCreditCardService;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCardRepository" /> class.
        /// </summary>
        /// <param name="mockCreditCardService">The mock credit card service.</param>
        public CreditCardRepository(IMockCreditCardService mockCreditCardService)
        {
            _mockCreditCardService = mockCreditCardService;
        }

        #endregion


        #region Implementation of ICreditCardRepository

        /// <summary>
        /// Determines whether [is credit card payment accepted] [the specified credit card number].
        /// </summary>
        /// <param name="creditCardNumber">The credit card number.</param>
        /// <returns>
        ///   <c>true</c> if [is credit card payment accepted] [the specified credit card number]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsCreditCardPaymentAccepted(string creditCardNumber)
        {
            return _mockCreditCardService.IsCreditCardPaymentAccepted(creditCardNumber);
        }

        #endregion
    }
}