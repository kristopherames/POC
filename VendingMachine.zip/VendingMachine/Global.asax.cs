﻿using Microsoft.Practices.Unity;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using VendingMachine.Factories;
using VendingMachine.Registries;

namespace VendingMachine
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private IUnityContainer _container;

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            _container = new UnityContainer();

            _container.AddNewExtension<MachineContentsHelperRegistry>();
            _container.AddNewExtension<PaymentHelperRegistry>();
            _container.AddNewExtension<SessionHelperRegistry>();
            _container.AddNewExtension<CreditCardRepositoryRegistry>();

            var factory = new ControllerFactory(_container);
            ControllerBuilder.Current.SetControllerFactory(factory);
        }
    }
}
