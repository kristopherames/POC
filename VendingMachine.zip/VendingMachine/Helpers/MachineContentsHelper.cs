﻿using VendingMachine.Areas.Simulator.Models;
using VendingMachine.Areas.Simulator.Models.ViewModels;

namespace VendingMachine.Helpers
{
    public class MachineContentsHelper : IMachineContentsHelper
    {
        #region Properties

        private readonly ISessionHelper _sessionHelper;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MachineContentsHelper"/> class.
        /// </summary>
        /// <param name="sessionHelper">The session helper.</param>
        public MachineContentsHelper(ISessionHelper sessionHelper)
        {
            _sessionHelper = sessionHelper;
        }

        #endregion


        #region Implementation of IMachineContentsHelper

        /// <summary>
        /// Removes the item from inventory.
        /// </summary>
        /// <param name="model">The model.</param>
        public void RemoveItemFromInventory(VendingMachineViewModel model)
        {
            model.MachineContents.InventoryList.Find(x => x.ItemNumber == model.ItemSelected).Quantity--;
            _sessionHelper.SaveVendingMachineContentsToSession(model.MachineContents);
        }

        /// <summary>
        /// Removes the change to return.
        /// </summary>
        /// <param name="machineContentsModel">The machine contents model.</param>
        /// <param name="changeToReturn">The change to return.</param>
        public void RemoveChangeToReturn(VendingMachineContentsModel machineContentsModel, CurrencyModel changeToReturn)
        {
            machineContentsModel.CashOnhand.DimeQuantity -= changeToReturn.DimeQuantity;
            machineContentsModel.CashOnhand.FiveDollarBillQuantity -= changeToReturn.FiveDollarBillQuantity;
            machineContentsModel.CashOnhand.OneDollarBillQuantity -= changeToReturn.OneDollarBillQuantity;
            machineContentsModel.CashOnhand.NickelQuantity -= changeToReturn.NickelQuantity;
            machineContentsModel.CashOnhand.QuarterQuantity -= changeToReturn.QuarterQuantity;

            _sessionHelper.SaveVendingMachineContentsToSession(machineContentsModel);
        }

        /// <summary>
        /// Adds the deposited cash.
        /// </summary>
        /// <param name="model">The model.</param>
        public void AddDepositedCash(VendingMachineViewModel model)
        {
            model.MachineContents.CashOnhand.DimeQuantity += model.CashDeposited.DimeQuantity;
            model.MachineContents.CashOnhand.FiveDollarBillQuantity += model.CashDeposited.FiveDollarBillQuantity;
            model.MachineContents.CashOnhand.OneDollarBillQuantity += model.CashDeposited.OneDollarBillQuantity;
            model.MachineContents.CashOnhand.NickelQuantity += model.CashDeposited.NickelQuantity;
            model.MachineContents.CashOnhand.QuarterQuantity += model.CashDeposited.QuarterQuantity;

            _sessionHelper.SaveVendingMachineContentsToSession(model.MachineContents);
        }

        #endregion
    }
}