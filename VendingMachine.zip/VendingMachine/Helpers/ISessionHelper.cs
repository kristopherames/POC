﻿using VendingMachine.Areas.Simulator.Models;

namespace VendingMachine.Helpers
{
    public interface ISessionHelper
    {
        /// <summary>
        /// Gets the vending machine contents from session.
        /// </summary>
        /// <returns></returns>
        VendingMachineContentsModel GetVendingMachineContentsFromSession();

        /// <summary>
        /// Saves the vending machine contents to session.
        /// </summary>
        /// <param name="model">The model.</param>
        void SaveVendingMachineContentsToSession(VendingMachineContentsModel model);
    }
}