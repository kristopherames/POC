﻿using VendingMachine.Areas.Simulator.Models;
using VendingMachine.Areas.Simulator.Models.ViewModels;

namespace VendingMachine.Helpers
{
    public interface IPaymentHelper
    {
        /// <summary>
        /// Calculates the amount charged to credit card.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        decimal CalculateAmountChargedToCreditCard(VendingMachineViewModel model);

        /// <summary>
        /// Calculates the amount paid.
        /// </summary>
        /// <param name="cashDeposited">The cash deposited.</param>
        /// <returns></returns>
        decimal CalculateAmountPaid(CurrencyModel cashDeposited);

        /// <summary>
        /// Gets the change to return.
        /// </summary>
        /// <param name="pendingCashOnhand">The pending cash onhand.</param>
        /// <param name="itemPrice">The item price.</param>
        /// <param name="amountPaid">The amount paid.</param>
        /// <returns></returns>
        CurrencyModel GetChangeToReturn(CurrencyModel pendingCashOnhand, decimal itemPrice, decimal amountPaid);

        /// <summary>
        /// Gets the cash to refund.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        VendingMachineViewModel GetCashToRefund(VendingMachineViewModel model);
    }
}