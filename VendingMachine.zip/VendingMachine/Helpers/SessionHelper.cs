﻿using System.Web;
using VendingMachine.Areas.Simulator.Models;
using VendingMachine.Repository;

namespace VendingMachine.Helpers
{
    public class SessionHelper : ISessionHelper
    {
        #region Properties

        private readonly IPhysicalContentsRepository _physicalContentsRepository;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SessionHelper" /> class.
        /// </summary>
        /// <param name="physicalContentsRepository">The physical contents repository.</param>
        public SessionHelper(IPhysicalContentsRepository physicalContentsRepository)
        {
            _physicalContentsRepository = physicalContentsRepository;
        }

        #endregion


        #region Implementation of ISessionHelper

        /// <summary>
        /// Gets the vending machine contents from session.
        /// </summary>
        /// <returns></returns>
        public VendingMachineContentsModel GetVendingMachineContentsFromSession()
        {
            var model = HttpContext.Current.Session["VendingMachineContents"];

            if (model != null)
            {
                return (VendingMachineContentsModel)model;
            }

            var initializedModel = new VendingMachineContentsModel();
            initializedModel.InventoryList = _physicalContentsRepository.InitializeInventoryList();
            initializedModel.CashOnhand = _physicalContentsRepository.CreateDefaultCashOnhand();

            return initializedModel;
        }

        /// <summary>
        /// Saves the vending machine contents to session.
        /// </summary>
        /// <param name="model">The model.</param>
        public void SaveVendingMachineContentsToSession(VendingMachineContentsModel model)
        {
            HttpContext.Current.Session["VendingMachineContents"] = model;
        }

        #endregion
    }
}