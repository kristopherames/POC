﻿using VendingMachine.Areas.Simulator.Models;
using VendingMachine.Areas.Simulator.Models.ViewModels;

namespace VendingMachine.Helpers
{
    public class PaymentHelper : IPaymentHelper
    {
        #region Implementation of IPaymentHelper

        /// <summary>
        /// Calculates the amount charged to credit card.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        public decimal CalculateAmountChargedToCreditCard(VendingMachineViewModel model)
        {
            var itemPrice = model.MachineContents.InventoryList.Find(x => x.ItemNumber == model.ItemSelected).Price;

            var serviceFeeAmount = itemPrice * .05m;

            return itemPrice + serviceFeeAmount;
        }

        /// <summary>
        /// Calculates the amount paid.
        /// </summary>
        /// <param name="cashDeposited">The cash deposited.</param>
        /// <returns></returns>
        public decimal CalculateAmountPaid(CurrencyModel cashDeposited)
        {
            decimal amountPaid = cashDeposited.FiveDollarBillQuantity * 5;
            amountPaid += cashDeposited.OneDollarBillQuantity;
            amountPaid += cashDeposited.QuarterQuantity * .25m;
            amountPaid += cashDeposited.DimeQuantity * .1m;
            amountPaid += cashDeposited.NickelQuantity * .05m;

            return amountPaid;
        }

        /// <summary>
        /// Gets the change to return.
        /// </summary>
        /// <param name="pendingCashOnhand">The pending cash onhand.</param>
        /// <param name="itemPrice">The item price.</param>
        /// <param name="amountPaid">The amount paid.</param>
        /// <returns></returns>
        public CurrencyModel GetChangeToReturn(CurrencyModel pendingCashOnhand, decimal itemPrice, decimal amountPaid)
        {
            var changeToReturn = new CurrencyModel();

            if (amountPaid == itemPrice)
            {
                return changeToReturn;
            }

            decimal changeTotal = 0;
            var changeDue = amountPaid - itemPrice;
            var previousChangeTotal = changeTotal;
            var isFirstIteration = true;

            while (changeTotal < changeDue)
            {
                var remainingAmount = changeDue - changeTotal;

                if (remainingAmount >= 5 && pendingCashOnhand.FiveDollarBillQuantity > 0)
                {
                    changeToReturn.OneDollarBillQuantity++;
                    remainingAmount -= 5;
                    changeTotal += 5;
                }
                else
                {
                    if (remainingAmount >= 1 && pendingCashOnhand.OneDollarBillQuantity > 0)
                    {
                        changeToReturn.OneDollarBillQuantity++;
                        remainingAmount -= 1;
                        changeTotal += 1;
                    }
                    else
                    {
                        if (remainingAmount >= .25m && pendingCashOnhand.QuarterQuantity > 0)
                        {
                            changeToReturn.QuarterQuantity++;
                            remainingAmount -= .25m;
                            changeTotal += .25m;
                        }
                        else
                        {
                            if (remainingAmount >= .1m && pendingCashOnhand.DimeQuantity > 0)
                            {
                                changeToReturn.DimeQuantity++;
                                remainingAmount -= .1m;
                                changeTotal += .1m;
                            }
                            else
                            {
                                if (remainingAmount >= .05m && pendingCashOnhand.NickelQuantity > 0)
                                {
                                    changeToReturn.NickelQuantity++;
                                    remainingAmount -= .05m;
                                    changeTotal += .05m;
                                }
                            }
                        }
                    }
                }

                if (!isFirstIteration && changeTotal == previousChangeTotal)
                {
                    //Unable to make change
                    return null;
                }

                isFirstIteration = false;
            }

            return changeToReturn;
        }

        /// <summary>
        /// Gets the cash to refund.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        public VendingMachineViewModel GetCashToRefund(VendingMachineViewModel model)
        {
            model.CashToReturn = new CurrencyModel();
            model.CashToReturn.DimeQuantity = model.CashDeposited.DimeQuantity;
            model.CashToReturn.FiveDollarBillQuantity = model.CashDeposited.FiveDollarBillQuantity;
            model.CashToReturn.OneDollarBillQuantity = model.CashDeposited.OneDollarBillQuantity;
            model.CashToReturn.NickelQuantity = model.CashDeposited.NickelQuantity;
            model.CashToReturn.QuarterQuantity = model.CashDeposited.QuarterQuantity;

            return model;
        }

        #endregion
    }
}