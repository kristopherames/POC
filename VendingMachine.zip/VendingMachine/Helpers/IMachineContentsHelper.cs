﻿using VendingMachine.Areas.Simulator.Models;
using VendingMachine.Areas.Simulator.Models.ViewModels;

namespace VendingMachine.Helpers
{
    public interface IMachineContentsHelper
    {
        /// <summary>
        /// Removes the item from inventory.
        /// </summary>
        /// <param name="model">The model.</param>
        void RemoveItemFromInventory(VendingMachineViewModel model);

        /// <summary>
        /// Removes the change to return.
        /// </summary>
        /// <param name="machineContentsModel">The machine contents model.</param>
        /// <param name="changeToReturn">The change to return.</param>
        void RemoveChangeToReturn(VendingMachineContentsModel machineContentsModel, CurrencyModel changeToReturn);

        /// <summary>
        /// Adds the deposited cash.
        /// </summary>
        /// <param name="model">The model.</param>
        void AddDepositedCash(VendingMachineViewModel model);
    }
}