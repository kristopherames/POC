﻿using Microsoft.Practices.Unity;
using VendingMachine.MockServices;

namespace VendingMachine.Registries
{
    public class MockCreditCardServiceRegistry : UnityContainerExtension
    {
        protected override void Initialize()
        {
            if (Container.IsRegistered<IMockCreditCardService>()) return;
            Container.RegisterType<IMockCreditCardService, MockCreditCardService>(
              new ContainerControlledLifetimeManager()
              );
        }
    }
}