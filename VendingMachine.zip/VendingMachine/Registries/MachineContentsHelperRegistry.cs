﻿using Microsoft.Practices.Unity;
using VendingMachine.Helpers;

namespace VendingMachine.Registries
{
    public class MachineContentsHelperRegistry : UnityContainerExtension
    {
        protected override void Initialize()
        {
            if (Container.IsRegistered<IMachineContentsHelper>()) return;
            Container.RegisterType<IMachineContentsHelper, MachineContentsHelper>(
              new ContainerControlledLifetimeManager()
              );

            Container.AddNewExtension<SessionHelperRegistry>();
        }
    }
}