﻿using Microsoft.Practices.Unity;
using VendingMachine.Repository;

namespace VendingMachine.Registries
{
    public class CreditCardRepositoryRegistry : UnityContainerExtension
    {
        protected override void Initialize()
        {
            if (Container.IsRegistered<ICreditCardRepository>()) return;
            Container.RegisterType<ICreditCardRepository, CreditCardRepository>(
              new ContainerControlledLifetimeManager()
              );

            Container.AddNewExtension<MockCreditCardServiceRegistry>();
        }
    }
}