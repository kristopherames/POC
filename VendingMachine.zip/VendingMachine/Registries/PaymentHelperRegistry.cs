﻿using Microsoft.Practices.Unity;
using VendingMachine.Helpers;

namespace VendingMachine.Registries
{
    public class PaymentHelperRegistry : UnityContainerExtension
    {
        protected override void Initialize()
        {
            if (Container.IsRegistered<IPaymentHelper>()) return;
            Container.RegisterType<IPaymentHelper, PaymentHelper>(
              new ContainerControlledLifetimeManager()
              );
        }
    }
}