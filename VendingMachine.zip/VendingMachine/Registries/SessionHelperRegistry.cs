﻿using Microsoft.Practices.Unity;
using VendingMachine.Helpers;

namespace VendingMachine.Registries
{
    public class SessionHelperRegistry : UnityContainerExtension
    {
        protected override void Initialize()
        {
            if (Container.IsRegistered<ISessionHelper>()) return;
            Container.RegisterType<ISessionHelper, SessionHelper>(
              new ContainerControlledLifetimeManager()
              );

            Container.AddNewExtension<PhysicalContentsRepositoryRegistry>();
        }
    }
}