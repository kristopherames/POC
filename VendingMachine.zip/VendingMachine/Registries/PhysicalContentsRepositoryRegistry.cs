﻿using Microsoft.Practices.Unity;
using VendingMachine.Repository;

namespace VendingMachine.Registries
{
    public class PhysicalContentsRepositoryRegistry : UnityContainerExtension
    {
        protected override void Initialize()
        {
            if (Container.IsRegistered<IPhysicalContentsRepository>()) return;
            Container.RegisterType<IPhysicalContentsRepository, PhysicalContentsRepository>(
              new ContainerControlledLifetimeManager()
              );
        }
    }
}