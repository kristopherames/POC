﻿namespace VendingMachine.MockServices
{
    public interface IMockCreditCardService
    {
        /// <summary>
        /// Determines whether [is credit card payment accepted] [the specified credit card number].
        /// </summary>
        /// <param name="creditCardNumber">The credit card number.</param>
        /// <returns>
        ///   <c>true</c> if [is credit card payment accepted] [the specified credit card number]; otherwise, <c>false</c>.
        /// </returns>
        bool IsCreditCardPaymentAccepted(string creditCardNumber);
    }
}