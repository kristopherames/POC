﻿using System;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.Practices.Unity;

namespace VendingMachine.Factories
{
    public class ControllerFactory : DefaultControllerFactory
    {
        #region Properties

        private readonly IUnityContainer _container;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ControllerFactory"/> class.
        /// </summary>
        /// <param name="container">The container.</param>
        public ControllerFactory(IUnityContainer container)
        {
            _container = container;
        }

        #endregion


        #region Method Overrides

        /// <summary>
        /// Retrieves the controller instance for the specified request context and controller type.
        /// </summary>
        /// <param name="requestContext">The context of the HTTP request, which includes the HTTP context and route data.</param>
        /// <param name="controllerType">The type of the controller.</param>
        /// <returns>
        /// The controller instance.
        /// </returns>
        protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
        {
            if (controllerType != null)
            {
                return _container.Resolve(controllerType) as IController;
            }
            else
            {
                return base.GetControllerInstance(requestContext, controllerType);
            }
        }

        #endregion
    }
}