﻿using System.Web.Mvc;

namespace VendingMachine.Areas.Simulator
{
    public class SimulatorAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Simulator";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Simulator_default",
                "Simulator/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}