﻿using System.Collections.Generic;
using System.Web.Mvc;
using VendingMachine.Areas.Simulator.Models;
using VendingMachine.Areas.Simulator.Models.ViewModels;
using VendingMachine.Helpers;
using VendingMachine.Repository;

namespace VendingMachine.Areas.Simulator.Controllers
{
    public class VendingMachineController : Controller
    {
        #region Properties

        private readonly IMachineContentsHelper _machineContentsHelper;
        private readonly IPaymentHelper _paymentHelper;
        private readonly ISessionHelper _sessionHelper;
        private readonly ICreditCardRepository _creditCardRepository;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="VendingMachineController"/> class.
        /// </summary>
        /// <param name="machineContentsHelper">The machine contents helper.</param>
        /// <param name="paymentHelper">The payment helper.</param>
        /// <param name="sessionHelper">The session helper.</param>
        /// <param name="creditCardRepository">The credit card repository.</param>
        public VendingMachineController(IMachineContentsHelper machineContentsHelper, IPaymentHelper paymentHelper, ISessionHelper sessionHelper, ICreditCardRepository creditCardRepository)
        {
            _machineContentsHelper = machineContentsHelper;
            _paymentHelper = paymentHelper;
            _sessionHelper = sessionHelper;
            _creditCardRepository = creditCardRepository;
        }

        #endregion


        #region Actions

        // GET: VendingMachine
        [HttpGet]
        public ActionResult Index()
        {
            var initializedViewModel = new VendingMachineViewModel();

            initializedViewModel.CashDeposited = new CurrencyModel();
            initializedViewModel.MachineContents =  _sessionHelper.GetVendingMachineContentsFromSession();

            return View("VendingMachine", initializedViewModel);
        }

        [HttpPost]
        public ActionResult Index(VendingMachineViewModel model)
        {
            //Clear hidden fields so that previous values are updated per the updated model
            ClearHiddenFields();

            model.MachineContents = _sessionHelper.GetVendingMachineContentsFromSession();
            
            //Add deposited cash to cash onhand
            _machineContentsHelper.AddDepositedCash(model);

            model.AmountDeposited = _paymentHelper.CalculateAmountPaid(model.CashDeposited);

            var itemSelected = model.MachineContents.InventoryList.Find(x => x.ItemNumber == model.ItemSelected);


            //Does the item exist?
            if (itemSelected == null)
            {
                model.ErrorMessage = "Invalid item number. Please try again.";
                return View("VendingMachine", model);
            }

            //Is the item in stock?
            if (itemSelected.Quantity == 0)
            {
                model.ErrorMessage = "Sold out.";
                return View("VendingMachine", model);
            }
            
            if (string.IsNullOrEmpty(model.CreditCardNumber))
            {
                //Did the customer pay enough?
                if (model.AmountDeposited < itemSelected.Price)
                {
                    model.ErrorMessage = "You didn't deposit enough money to purchase that item.";
                    return View("VendingMachine", model);
                }

                //Calculate change
                var changeToReturn = _paymentHelper.GetChangeToReturn(model.MachineContents.CashOnhand, itemSelected.Price, model.AmountDeposited);

                if (changeToReturn == null)
                {
                    //Return the money deposited
                    ApplyRefund(model);
                    model.ErrorMessage = "Unable to make change for that item. Please try exact change.";
                    return View("VendingMachine", model);
                }

                //Complete the transaction
                model = CompleteCashTransaction(model, changeToReturn);
            }
            else
            {
                //Did the transaction get approved?
                var wasTransactionApproved = _creditCardRepository.IsCreditCardPaymentAccepted(model.CreditCardNumber);

                if (!wasTransactionApproved)
                {
                    model.ErrorMessage = "Transaction declined.";
                    return View("VendingMachine", model);
                }

                //Complete transaction
                model = CompleteCreditCardTransaction(model);
            }
            
            return View("VendingMachine", model);
        }

        [HttpPost]
        public ActionResult CancelPurchase(VendingMachineViewModel model)
        {
            model.MachineContents = _sessionHelper.GetVendingMachineContentsFromSession();

            //Clear hidden fields so that previous values are updated per the updated model
            ClearHiddenFields();

            model = _paymentHelper.GetCashToRefund(model);

            model.ResultMessage = GetChangeReturnedMessage(model.CashDeposited);

            ResetPersistedModelData(model);

            return View("VendingMachine", model);
        }

        #endregion


        #region Private Helper Methods

        private void ClearHiddenFields()
        {
            ModelState.Remove("AmountDeposited");
            ModelState.Remove("ItemSelected");
            ModelState.Remove("CreditCardNumber");
            ModelState.Remove("CashDeposited.FiveDollarBillQuantity");
            ModelState.Remove("CashDeposited.OneDollarBillQuantity");
            ModelState.Remove("CashDeposited.QuarterQuantity");
            ModelState.Remove("CashDeposited.DimeQuantity");
            ModelState.Remove("CashDeposited.NickelQuantity");
        }

        private void ResetPersistedModelData(VendingMachineViewModel model)
        {
            model.CashDeposited = new CurrencyModel();
            model.AmountDeposited = 0;
        }

        private void ApplyRefund(VendingMachineViewModel model)
        {
            //Update cash onhand
            _machineContentsHelper.RemoveChangeToReturn(model.MachineContents, model.CashDeposited);

            //Return the money deposited
            model.CashToReturn = model.CashDeposited;

            ResetPersistedModelData(model);
        }

        private VendingMachineViewModel CompleteCreditCardTransaction(VendingMachineViewModel model)
        {
            //Update inventory
            _machineContentsHelper.RemoveItemFromInventory(model);

            //Set the change that will be returned
            ApplyRefund(model);

            //Calculate amount charged to credit card
            model.ResultMessage = _paymentHelper.CalculateAmountChargedToCreditCard(model).ToString("C") + " was charged to your card including 5% service fee. ";
            model.ResultMessage += GetChangeReturnedMessage(model.CashToReturn);

            return model;
        }

        private VendingMachineViewModel CompleteCashTransaction(VendingMachineViewModel model, CurrencyModel changeToReturn)
        {
            //Set the change that will be returned
            model.CashToReturn = changeToReturn;

            //Update cash onhand
            _machineContentsHelper.RemoveChangeToReturn(model.MachineContents, changeToReturn);

            //Update inventory
            _machineContentsHelper.RemoveItemFromInventory(model);

            //Update the model to be ready for new purchase
            ResetPersistedModelData(model);

            model.ResultMessage = GetChangeReturnedMessage(model.CashToReturn);

            return model;
        }

        private string GetChangeReturnedMessage(CurrencyModel changeToReturn)
        {
            var messageList = new List<string>();

            if (changeToReturn.FiveDollarBillQuantity > 0)
            {
                messageList.Add(changeToReturn.FiveDollarBillQuantity + " x $5");
            }

            if (changeToReturn.OneDollarBillQuantity > 0)
            {
                messageList.Add(changeToReturn.OneDollarBillQuantity + " x $1");
            }

            if (changeToReturn.QuarterQuantity > 0)
            {
                messageList.Add(changeToReturn.QuarterQuantity + " x 25¢");
            }

            if (changeToReturn.DimeQuantity > 0)
            {
                messageList.Add(changeToReturn.DimeQuantity + " x 10¢");
            }

            if (changeToReturn.NickelQuantity > 0)
            {
                messageList.Add(changeToReturn.NickelQuantity + " x 5¢");
            }

            if (messageList.Count > 0)
            {
                return "Change returned: " + string.Join(", ", messageList);
            }

            return "";
        }

        #endregion
    }
}