﻿using System.Collections.Generic;

namespace VendingMachine.Areas.Simulator.Models
{
    public class VendingMachineContentsModel
    {
        /// <summary>
        /// Gets or sets the inventory list.
        /// </summary>
        /// <value>
        /// The inventory list.
        /// </value>
        public List<InventoryItemModel> InventoryList { get; set; }

        /// <summary>
        /// Gets or sets the cash onhand.
        /// </summary>
        /// <value>
        /// The cash onhand.
        /// </value>
        public CurrencyModel CashOnhand { get; set; }
    }
}