﻿namespace VendingMachine.Areas.Simulator.Models.ViewModels
{
    public class VendingMachineViewModel
    {
        /// <summary>
        /// Gets or sets the item selected.
        /// </summary>
        /// <value>
        /// The item selected.
        /// </value>
        public string ItemSelected { get; set; }

        /// <summary>
        /// Gets or sets the credit card number.
        /// </summary>
        /// <value>
        /// The credit card number.
        /// </value>
        public string CreditCardNumber { get; set; }

        /// <summary>
        /// Gets or sets the cash deposited.
        /// </summary>
        /// <value>
        /// The cash deposited.
        /// </value>
        public CurrencyModel CashDeposited { get; set; }

        /// <summary>
        /// Gets or sets the cash to return.
        /// </summary>
        /// <value>
        /// The cash to return.
        /// </value>
        public CurrencyModel CashToReturn { get; set; }

        /// <summary>
        /// Gets or sets the amount deposited.
        /// </summary>
        /// <value>
        /// The amount deposited.
        /// </value>
        public decimal AmountDeposited { get; set; }

        /// <summary>
        /// Gets or sets the result message.
        /// </summary>
        /// <value>
        /// The result message.
        /// </value>
        public string ResultMessage { get; set; }

        /// <summary>
        /// Gets or sets the error message.
        /// </summary>
        /// <value>
        /// The error message.
        /// </value>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the machine contents.
        /// </summary>
        /// <value>
        /// The machine contents.
        /// </value>
        public VendingMachineContentsModel MachineContents { get; set; }
    }
}