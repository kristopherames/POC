﻿namespace VendingMachine.Areas.Simulator.Models
{
    public class InventoryItemModel
    {
        #region Properties

        private string _itemNumber;
        private string _description;
        private decimal _price;

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>
        /// The quantity.
        /// </value>
        public int Quantity { get; set; }

        /// <summary>
        /// Gets the item number.
        /// </summary>
        /// <value>
        /// The item number.
        /// </value>
        public string ItemNumber { get { return _itemNumber; } }

        /// <summary>
        /// Gets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get { return _description; } }

        /// <summary>
        /// Gets the price.
        /// </summary>
        /// <value>
        /// The price.
        /// </value>
        public decimal Price { get { return _price; } }

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="InventoryItemModel" /> class.
        /// </summary>
        /// <param name="itemNumber">The item number.</param>
        /// <param name="description">The description.</param>
        /// <param name="price">The price.</param>
        public InventoryItemModel(string itemNumber, string description, decimal price)
        {
            _itemNumber = itemNumber;
            _description = description;
            _price = price;
        }

        #endregion
    }
}
