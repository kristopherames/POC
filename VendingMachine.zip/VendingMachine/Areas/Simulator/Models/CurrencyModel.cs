﻿using System.ComponentModel.DataAnnotations;

namespace VendingMachine.Areas.Simulator.Models
{
    public class CurrencyModel
    {
        /// <summary>
        /// Gets or sets the five dollar bill quantity.
        /// </summary>
        /// <value>
        /// The five dollar bill quantity.
        /// </value>
        [Display(Name = "$5")]
        public int FiveDollarBillQuantity { get; set; }

        /// <summary>
        /// Gets or sets the one dollar bill quantity.
        /// </summary>
        /// <value>
        /// The one dollar bill quantity.
        /// </value>
        [Display(Name = "$1")]
        public int OneDollarBillQuantity { get; set; }

        /// <summary>
        /// Gets or sets the quarter quantity.
        /// </summary>
        /// <value>
        /// The quarter quantity.
        /// </value>
        [Display(Name = "25¢")]
        public int QuarterQuantity { get; set; }

        /// <summary>
        /// Gets or sets the dime quantity.
        /// </summary>
        /// <value>
        /// The dime quantity.
        /// </value>
        [Display(Name = "10¢")]
        public int DimeQuantity { get; set; }

        /// <summary>
        /// Gets or sets the nickel quantity.
        /// </summary>
        /// <value>
        /// The nickel quantity.
        /// </value>
        [Display(Name = "5¢")]
        public int NickelQuantity { get; set; }
    }
}
