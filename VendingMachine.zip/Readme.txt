Please host as application in IIS. I always run my apps using IIS so that's the way I tested it while developing.

Attach to process if you want to step through the code in debug mode.

It ran fine for me as an IIS application, but it threw errors when I ran from Visual Studio IIS Express. 